const checkAccount = async () => {

  const validAccount = await Math.floor(Math.random() * 1E16);

};

module.exports = checkAccount;
